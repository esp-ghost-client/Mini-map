# CMD World Explorer 1.0.0
Fabric client mod for Minecraft Java 1.21.11 (desktop + PojavLauncher). By CMD Team.

## Default keys
Only two keys are bound by default (so they do not clash with other mods):
- **Z** - world map
- **B** - waypoint manager

Unbound until you pick a key (Options > Controls > Key Binds > CMD World Explorer):
add waypoint here, toggle minimap, minimap zoom in/out. All of these also exist as buttons inside the map / settings screens.

## Build the .jar
### A) GitHub Actions (no setup)
1. Create a GitHub repo, upload ALL files from this folder (the repo root must contain `build.gradle`).
2. Open Actions > "Build CMD World Explorer" > Run workflow.
3. Download the `cmd_world_explorer-jar` artifact. Use `cmd_world_explorer-1.0.0.jar` (not the `-sources` one).

### B) Locally
Install JDK 21 and Gradle 9.2.1, then in this folder: `gradle build`
The jar is in `build/libs/`.

## Install (PojavLauncher / desktop)
1. Install a Fabric 1.21.11 profile (Fabric Loader 0.18.1+).
2. Put `fabric-api` for 1.21.11 and `cmd_world_explorer-1.0.0.jar` in the `mods` folder of that profile.
3. Start the game. On Android, map a Pojav on-screen button to the Z / B keys.

## Features
- Minimap: square/circle, resize, opacity, zoom, drag to move (Settings > Minimap), player arrow, N indicator, X/Y/Z, dimension.
- World map screen: pan, zoom, select, info, create waypoints (mouse and touch).
- Waypoints: name (Persian/English/numbers, duplicates allowed), X/Y/Z, colour, icon, category, dimension; saved in `config/cmd_world_explorer/waypoints.json`.
- Death tracker: "DEATH POINT #01" with red skull, history, rename/delete.
- End Cities / End Ships: manual markers, separate tabs.
- Manager: tabs, search, sort by distance/name/newest, rename, icon, colour, delete, navigate, copy coordinates.
- Navigation: name, coords, live distance, direction arrow, current-dimension check.
- Explored terrain saved per world and dimension (`config/cmd_world_explorer/maps`).
- Corrupted files are moved aside (`.corrupt-...`) instead of crashing.

## Known limitations
- Not compiled or tested in the environment where this was written. Expect to fix a few compile errors on first build (Minecraft 1.21.11 UI classes changed a lot).
- Only terrain your client has actually received is drawn. No fake terrain, no structure detection (End Cities/Ships are manual).
- Navigation is a straight-line arrow, not a route.
- Nether/Overworld coordinates are not converted (x8).
- Persian text typing depends on your keyboard/IME in Minecraft; rendering uses the game font.
- Buttons use the vanilla look; dark theme applies to panels and backgrounds.
- Y of a clicked map spot is the surface height if the chunk is loaded, otherwise your current Y.

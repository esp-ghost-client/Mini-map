package com.cmdteam.worldexplorer.util;

import net.minecraft.client.Minecraft;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.util.Mth;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.levelgen.Heightmap;

import java.util.Locale;

public final class Geo {
    private Geo() {}

    /** Standing Y at x,z if the chunk is loaded, otherwise the player's Y. */
    public static int surfaceY(ClientLevel level, LocalPlayer p, int x, int z) {
        if (level.dimension() == Level.NETHER) return p.getBlockY();
        if (level.hasChunk(x >> 4, z >> 4)) return level.getHeight(Heightmap.Types.WORLD_SURFACE, x, z);
        return p.getBlockY();
    }

    public static String fmtDist(double d) {
        if (d < 1000) return String.format(Locale.ROOT, "%d m", (int) Math.round(d));
        return String.format(Locale.ROOT, "%.1f km", d / 1000.0);
    }

    /** Degrees: 0 = straight ahead, positive = target is to the right. */
    public static double relativeAngle(LocalPlayer p, double tx, double tz) {
        double dx = tx + 0.5 - p.getX();
        double dz = tz + 0.5 - p.getZ();
        double target = Math.toDegrees(Math.atan2(-dx, dz));
        return Mth.wrapDegrees((float) (target - p.getYRot()));
    }

    public static void copy(String text) {
        Minecraft.getInstance().keyboardHandler.setClipboard(text);
    }

    public static int parseInt(String s) {
        try {
            return Integer.parseInt(s.trim());
        } catch (Exception e) {
            return 0;
        }
    }

    public static String shorten(String s, int max) {
        return s.length() <= max ? s : s.substring(0, Math.max(1, max - 1)) + "…";
    }
}

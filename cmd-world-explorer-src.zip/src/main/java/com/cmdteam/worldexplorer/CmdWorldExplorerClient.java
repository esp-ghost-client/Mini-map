package com.cmdteam.worldexplorer;

import com.cmdteam.worldexplorer.data.*;
import com.cmdteam.worldexplorer.map.ChunkScanner;
import com.cmdteam.worldexplorer.map.MinimapRenderer;
import com.cmdteam.worldexplorer.ui.MapScreen;
import com.cmdteam.worldexplorer.ui.WaypointEditScreen;
import com.cmdteam.worldexplorer.ui.WaypointManagerScreen;
import com.mojang.blaze3d.platform.InputConstants;
import com.mojang.logging.LogUtils;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientLifecycleEvents;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayConnectionEvents;
import net.fabricmc.fabric.api.client.rendering.v1.hud.HudElementRegistry;
import net.fabricmc.fabric.api.client.rendering.v1.hud.VanillaHudElements;
import net.minecraft.client.KeyMapping;
import net.minecraft.client.Minecraft;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.Identifier;
import net.minecraft.util.Mth;
import org.lwjgl.glfw.GLFW;
import org.slf4j.Logger;

public class CmdWorldExplorerClient implements ClientModInitializer {
    public static final String MOD_ID = "cmd_world_explorer";
    public static final Logger LOGGER = LogUtils.getLogger();

    private static KeyMapping openMap, openManager, addWaypoint, toggleMinimap, zoomIn, zoomOut;
    private static boolean wasDead = false;
    private static int ticks = 0;

    @Override
    public void onInitializeClient() {
        ModConfig.load();
        WaypointManager.load();

        KeyMapping.Category category = KeyMapping.Category.register(Identifier.fromNamespaceAndPath(MOD_ID, "main"));
        // Only Z and B get a default key; everything else is unbound (rebind in Options > Controls).
        openMap = key("open_map", GLFW.GLFW_KEY_Z, category);
        openManager = key("open_waypoints", GLFW.GLFW_KEY_B, category);
        addWaypoint = key("add_waypoint", GLFW.GLFW_KEY_UNKNOWN, category);
        toggleMinimap = key("toggle_minimap", GLFW.GLFW_KEY_UNKNOWN, category);
        zoomIn = key("zoom_in", GLFW.GLFW_KEY_UNKNOWN, category);
        zoomOut = key("zoom_out", GLFW.GLFW_KEY_UNKNOWN, category);

        HudElementRegistry.attachElementBefore(VanillaHudElements.CHAT,
                Identifier.fromNamespaceAndPath(MOD_ID, "minimap"), MinimapRenderer::renderHud);

        ClientTickEvents.END_CLIENT_TICK.register(CmdWorldExplorerClient::tick);
        ClientPlayConnectionEvents.JOIN.register((handler, sender, client) -> onJoin(client));
        ClientPlayConnectionEvents.DISCONNECT.register((handler, client) -> {
            MapStore.flush(false);
            ModConfig.save();
            wasDead = false;
        });
        ClientLifecycleEvents.CLIENT_STOPPING.register(client -> {
            MapStore.flush(true);
            ModConfig.save();
        });
        LOGGER.info("[CMD] World Explorer loaded");
    }

    private static KeyMapping key(String name, int code, KeyMapping.Category cat) {
        return KeyBindingHelper.registerKeyBinding(
                new KeyMapping("key." + MOD_ID + "." + name, InputConstants.Type.KEYSYM, code, cat));
    }

    private static String worldId(Minecraft mc) {
        String raw;
        if (mc.getSingleplayerServer() != null) raw = "sp_" + mc.getSingleplayerServer().getWorldData().getLevelName();
        else if (mc.getCurrentServer() != null) raw = "mp_" + mc.getCurrentServer().ip;
        else raw = "unknown";
        return Storage.safeName(raw);
    }

    private static void onJoin(Minecraft mc) {
        String id = worldId(mc);
        WaypointManager.setWorld(id);
        MapStore.setWorld(id);
        ChunkScanner.reset();
        wasDead = false;
    }

    private static void tick(Minecraft mc) {
        LocalPlayer p = mc.player;
        if (p == null || mc.level == null) return;
        ChunkScanner.tick(mc);

        boolean dead = p.isDeadOrDying();
        if (dead && !wasDead) {
            Waypoint w = WaypointManager.addDeath(Dims.key(mc.level), p.getBlockX(), p.getBlockY(), p.getBlockZ());
            p.displayClientMessage(Component.literal("[CMD] " + w.name + " saved: " + w.coords()), false);
        }
        wasDead = dead;

        ModConfig c = ModConfig.get();
        if (mc.screen == null) {
            while (openMap.consumeClick()) mc.setScreen(new MapScreen());
            while (openManager.consumeClick()) mc.setScreen(new WaypointManagerScreen(null));
            while (addWaypoint.consumeClick()) {
                Waypoint w = Waypoint.create(WaypointCategory.CUSTOM, WaypointManager.world(), Dims.key(mc.level),
                        p.getBlockX(), p.getBlockY(), p.getBlockZ());
                mc.setScreen(new WaypointEditScreen(null, w, true));
            }
            while (toggleMinimap.consumeClick()) c.minimapEnabled = !c.minimapEnabled;
            while (zoomIn.consumeClick()) c.zoomIndex = Mth.clamp(c.zoomIndex - 1, 0, 6);
            while (zoomOut.consumeClick()) c.zoomIndex = Mth.clamp(c.zoomIndex + 1, 0, 6);
        }

        if (++ticks >= 1200) { // once a minute
            ticks = 0;
            MapStore.flush(false);
        }
    }
}

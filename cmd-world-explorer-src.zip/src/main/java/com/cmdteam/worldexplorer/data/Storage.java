package com.cmdteam.worldexplorer.data;

import com.cmdteam.worldexplorer.CmdWorldExplorerClient;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import net.fabricmc.loader.api.FabricLoader;

import java.io.IOException;
import java.io.Reader;
import java.nio.charset.StandardCharsets;
import java.nio.file.AtomicMoveNotSupportedException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;

/** File helpers: UTF-8 JSON, atomic writes, corrupted-file quarantine. */
public final class Storage {
    public static final Gson GSON = new GsonBuilder().setPrettyPrinting().disableHtmlEscaping().create();

    private Storage() {}

    public static Path dir() {
        return FabricLoader.getInstance().getConfigDir().resolve("cmd_world_explorer");
    }

    public static Path mapsDir() {
        return dir().resolve("maps");
    }

    public static <T> T read(Path file, Class<T> type) {
        if (!Files.isRegularFile(file)) return null;
        try (Reader r = Files.newBufferedReader(file, StandardCharsets.UTF_8)) {
            return GSON.fromJson(r, type);
        } catch (Exception e) {
            CmdWorldExplorerClient.LOGGER.warn("[CMD] Could not read {} - moving it aside", file, e);
            quarantine(file);
            return null;
        }
    }

    public static boolean write(Path file, Object data) {
        try {
            Files.createDirectories(file.getParent());
            Path tmp = file.resolveSibling(file.getFileName() + ".tmp");
            Files.writeString(tmp, GSON.toJson(data), StandardCharsets.UTF_8);
            moveReplace(tmp, file);
            return true;
        } catch (Exception e) {
            CmdWorldExplorerClient.LOGGER.warn("[CMD] Could not write {}", file, e);
            return false;
        }
    }

    public static void moveReplace(Path from, Path to) throws IOException {
        try {
            Files.move(from, to, StandardCopyOption.REPLACE_EXISTING, StandardCopyOption.ATOMIC_MOVE);
        } catch (AtomicMoveNotSupportedException e) {
            Files.move(from, to, StandardCopyOption.REPLACE_EXISTING);
        }
    }

    public static void quarantine(Path file) {
        try {
            Files.move(file, file.resolveSibling(file.getFileName() + ".corrupt-" + System.currentTimeMillis()));
        } catch (Exception ignored) {
        }
    }

    /** File-system safe name with a hash suffix so different names never collide. */
    public static String safeName(String raw) {
        String s = raw.replaceAll("[^A-Za-z0-9._-]", "_");
        if (s.length() > 40) s = s.substring(0, 40);
        return s + "_" + Integer.toHexString(raw.hashCode());
    }
}

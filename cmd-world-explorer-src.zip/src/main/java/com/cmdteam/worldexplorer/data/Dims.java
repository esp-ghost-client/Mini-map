package com.cmdteam.worldexplorer.data;

import net.minecraft.resources.ResourceKey;
import net.minecraft.world.level.Level;

public final class Dims {
    private Dims() {}

    public static String key(Level level) {
        ResourceKey<Level> k = level.dimension();
        if (k == Level.OVERWORLD) return "overworld";
        if (k == Level.NETHER) return "the_nether";
        if (k == Level.END) return "the_end";
        String s = k.toString().toLowerCase().replaceAll("[^a-z0-9_.-]", "_");
        return s.length() > 60 ? s.substring(s.length() - 60) : s;
    }

    public static String pretty(String key) {
        return switch (key) {
            case "overworld" -> "Overworld";
            case "the_nether" -> "The Nether";
            case "the_end" -> "The End";
            default -> key;
        };
    }

    public static int color(String key) {
        return switch (key) {
            case "overworld" -> 0xFF4ADE80;
            case "the_nether" -> 0xFFEF4444;
            case "the_end" -> 0xFFC084FC;
            default -> 0xFF9CA3AF;
        };
    }
}

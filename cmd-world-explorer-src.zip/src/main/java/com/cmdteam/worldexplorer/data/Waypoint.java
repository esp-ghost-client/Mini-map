package com.cmdteam.worldexplorer.data;

import java.util.UUID;

/** One saved waypoint. Names may contain Persian, English, numbers, anything. */
public final class Waypoint {
    public String id = UUID.randomUUID().toString();
    public String name = "Waypoint";
    public int x, y, z;
    public String world = "";
    public String dimension = "overworld";
    public int color = 0xA855F7;
    public String icon = "DIAMOND";
    public String category = "CUSTOM";
    public int deathNumber = 0;
    public long createdAt = System.currentTimeMillis();

    public WaypointCategory cat() {
        return WaypointCategory.parse(category);
    }

    public WaypointIcon iconType() {
        return WaypointIcon.parse(icon);
    }

    public void normalize() {
        if (id == null || id.isEmpty()) id = UUID.randomUUID().toString();
        if (name == null) name = "Waypoint";
        if (world == null) world = "";
        if (dimension == null || dimension.isEmpty()) dimension = "overworld";
        if (icon == null) icon = "DIAMOND";
        if (category == null) category = "CUSTOM";
    }

    public double distanceTo(double px, double py, double pz) {
        double dx = x + 0.5 - px, dy = y - py, dz = z + 0.5 - pz;
        return Math.sqrt(dx * dx + dy * dy + dz * dz);
    }

    public String coords() {
        return "X: " + x + " | Y: " + y + " | Z: " + z;
    }

    public static Waypoint create(WaypointCategory cat, String world, String dim, int x, int y, int z) {
        Waypoint w = new Waypoint();
        w.world = world;
        w.dimension = dim;
        w.x = x;
        w.y = y;
        w.z = z;
        w.category = cat.name();
        switch (cat) {
            case END_CITY -> {
                w.name = "End City";
                w.icon = "END_CITY";
                w.color = 0xC084FC;
            }
            case END_SHIP -> {
                w.name = "End Ship";
                w.icon = "END_SHIP";
                w.color = 0x38BDF8;
            }
            case DEATH -> {
                w.name = "DEATH POINT";
                w.icon = "SKULL";
                w.color = 0xEF4444;
            }
            default -> {
                w.name = "Waypoint";
                w.icon = "DIAMOND";
                w.color = 0xA855F7;
            }
        }
        return w;
    }
}

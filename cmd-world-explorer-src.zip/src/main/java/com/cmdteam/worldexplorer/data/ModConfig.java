package com.cmdteam.worldexplorer.data;

import java.nio.file.Path;
import java.util.HashMap;
import java.util.Map;

/** User settings, saved to config/cmd_world_explorer/config.json. */
public final class ModConfig {
    public boolean minimapEnabled = true;
    public boolean circular = false;
    public int size = 96;
    public float opacity = 0.85f;
    public int zoomIndex = 2;
    public int posX = -1;   // -1 = snapped to the right edge
    public int posY = 8;
    public boolean showCoords = true;
    public boolean showDimension = true;
    public boolean showWaypoints = true;
    public boolean showWaypointNames = true;
    public boolean showNorth = true;
    public boolean showNavigation = true;

    public int scanRadius = 5;
    public int maxChunks = 20000;
    public int longPressMs = 500;
    public int maxDeathHistory = 20;
    public int mapZoomIndex = 3;

    public String navTarget = "";
    public Map<String, Integer> deathCounters = new HashMap<>();

    private static ModConfig INSTANCE = new ModConfig();

    public static ModConfig get() {
        return INSTANCE;
    }

    private static Path file() {
        return Storage.dir().resolve("config.json");
    }

    public static void load() {
        ModConfig c = Storage.read(file(), ModConfig.class);
        INSTANCE = c == null ? new ModConfig() : c;
        INSTANCE.clamp();
    }

    public static void save() {
        INSTANCE.clamp();
        Storage.write(file(), INSTANCE);
    }

    private void clamp() {
        size = Math.max(64, Math.min(200, size));
        opacity = Math.max(0.3f, Math.min(1f, opacity));
        zoomIndex = Math.max(0, Math.min(6, zoomIndex));
        mapZoomIndex = Math.max(0, Math.min(6, mapZoomIndex));
        scanRadius = Math.max(2, Math.min(10, scanRadius));
        maxChunks = Math.max(1000, Math.min(100000, maxChunks));
        longPressMs = Math.max(200, Math.min(2000, longPressMs));
        maxDeathHistory = Math.max(1, Math.min(200, maxDeathHistory));
        if (navTarget == null) navTarget = "";
        if (deathCounters == null) deathCounters = new HashMap<>();
    }
}

package com.cmdteam.worldexplorer.data;

import net.minecraft.client.gui.GuiGraphics;

/** 7x7 pixel-art icons drawn with rectangles (no texture files needed). */
public enum WaypointIcon {
    DIAMOND("...#...", "..###..", ".#####.", "#######", ".#####.", "..###..", "...#..."),
    SQUARE("#######", "#######", "#######", "#######", "#######", "#######", "#######"),
    CIRCLE("..###..", ".#####.", "#######", "#######", "#######", ".#####.", "..###.."),
    TRIANGLE("...#...", "...#...", "..###..", "..###..", ".#####.", ".#####.", "#######"),
    STAR("...#...", "...#...", "#######", ".#####.", "..###..", ".##.##.", "#.....#"),
    HOME("...#...", "..###..", ".#####.", "#######", ".#####.", ".##.##.", ".##.##."),
    FLAG("#.#####", "#.#####", "#.#####", "#......", "#......", "#......", "#......"),
    SKULL(".#####.", "#######", "##.#.##", "#######", ".#####.", ".#.#.#.", ".#.#.#."),
    END_CITY("#.#.#.#", "#######", ".#####.", ".#.#.#.", ".#####.", ".#####.", "#######"),
    END_SHIP("...#...", "..##...", ".###...", "#######", ".#####.", "..###..", ".......");

    private final String[] rows;

    WaypointIcon(String... rows) {
        this.rows = rows;
    }

    public static WaypointIcon parse(String s) {
        try {
            return valueOf(s);
        } catch (Exception e) {
            return DIAMOND;
        }
    }

    public void draw(GuiGraphics g, int x, int y, int scale, int argb) {
        for (int r = 0; r < 7; r++) {
            String row = rows[r];
            int c = 0;
            while (c < 7) {
                if (row.charAt(c) == '#') {
                    int start = c;
                    while (c < 7 && row.charAt(c) == '#') c++;
                    g.fill(x + start * scale, y + r * scale, x + c * scale, y + (r + 1) * scale, argb);
                } else {
                    c++;
                }
            }
        }
    }

    /** Icon with a soft dark shadow so it is readable on any terrain. */
    public void drawShadowed(GuiGraphics g, int x, int y, int scale, int rgb) {
        draw(g, x + 1, y + 1, scale, 0xAA000000);
        draw(g, x, y, scale, 0xFF000000 | (rgb & 0xFFFFFF));
    }
}

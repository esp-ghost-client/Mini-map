package com.cmdteam.worldexplorer.data;

import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

/** Holds every waypoint (all worlds) and persists them to waypoints.json. */
public final class WaypointManager {
    public static final String TEMP_ID = "__temp__";

    private static final class FileData {
        int version = 1;
        List<Waypoint> waypoints = new ArrayList<>();
    }

    private static List<Waypoint> all = new ArrayList<>();
    private static String world = "";
    private static Waypoint temp;

    private WaypointManager() {}

    private static Path file() {
        return Storage.dir().resolve("waypoints.json");
    }

    public static void load() {
        FileData d = Storage.read(file(), FileData.class);
        all = new ArrayList<>();
        if (d != null && d.waypoints != null) {
            for (Waypoint w : d.waypoints) {
                if (w == null) continue;
                w.normalize();
                all.add(w);
            }
        }
    }

    public static void save() {
        FileData d = new FileData();
        d.waypoints = all;
        Storage.write(file(), d);
    }

    public static void setWorld(String w) {
        world = w;
        temp = null;
    }

    public static String world() {
        return world;
    }

    public static List<Waypoint> current() {
        List<Waypoint> out = new ArrayList<>();
        for (Waypoint w : all) if (w.world.equals(world)) out.add(w);
        return out;
    }

    public static Waypoint find(String id) {
        for (Waypoint w : all) if (w.world.equals(world) && w.id.equals(id)) return w;
        return null;
    }

    public static void add(Waypoint w) {
        w.normalize();
        if (w.world.isEmpty()) w.world = world;
        all.add(w);
        save();
    }

    public static void remove(Waypoint w) {
        all.remove(w);
        if (w.id.equals(ModConfig.get().navTarget)) ModConfig.get().navTarget = "";
        save();
    }

    public static Waypoint addDeath(String dim, int x, int y, int z) {
        ModConfig cfg = ModConfig.get();
        int n = cfg.deathCounters.getOrDefault(world, 0);
        for (Waypoint w : current()) if (w.cat() == WaypointCategory.DEATH) n = Math.max(n, w.deathNumber);
        n++;
        cfg.deathCounters.put(world, n);
        Waypoint w = Waypoint.create(WaypointCategory.DEATH, world, dim, x, y, z);
        w.deathNumber = n;
        w.name = String.format("DEATH POINT #%02d", n);
        all.add(w);

        List<Waypoint> deaths = new ArrayList<>();
        for (Waypoint o : current()) if (o.cat() == WaypointCategory.DEATH) deaths.add(o);
        deaths.sort(Comparator.comparingLong(o -> o.createdAt));
        while (deaths.size() > cfg.maxDeathHistory) {
            Waypoint old = deaths.remove(0);
            all.remove(old);
            if (old.id.equals(cfg.navTarget)) cfg.navTarget = "";
        }
        save();
        ModConfig.save();
        return w;
    }

    public static int deleteAllDeaths() {
        List<Waypoint> rm = new ArrayList<>();
        for (Waypoint w : current()) if (w.cat() == WaypointCategory.DEATH) rm.add(w);
        all.removeAll(rm);
        save();
        return rm.size();
    }

    // ---- navigation target ----
    public static Waypoint navTarget() {
        String id = ModConfig.get().navTarget;
        if (id == null || id.isEmpty()) return null;
        if (TEMP_ID.equals(id)) return temp;
        return find(id);
    }

    public static void setNav(Waypoint w) {
        ModConfig.get().navTarget = w == null ? "" : w.id;
        ModConfig.save();
    }

    public static void setTemp(String dim, int x, int y, int z) {
        Waypoint t = Waypoint.create(WaypointCategory.CUSTOM, world, dim, x, y, z);
        t.id = TEMP_ID;
        t.name = "Marked location";
        t.icon = "FLAG";
        t.color = 0xFFFFFF;
        temp = t;
        ModConfig.get().navTarget = TEMP_ID;
        ModConfig.save();
    }

    // ---- import / export ----
    public static int exportTo(Path target) {
        FileData d = new FileData();
        d.waypoints = current();
        Storage.write(target, d);
        return d.waypoints.size();
    }

    public static int importFrom(Path source) {
        FileData d = Storage.read(source, FileData.class);
        if (d == null || d.waypoints == null) return -1;
        int added = 0;
        for (Waypoint w : d.waypoints) {
            if (w == null) continue;
            w.normalize();
            w.world = world;
            if (find(w.id) != null) w.id = java.util.UUID.randomUUID().toString();
            all.add(w);
            added++;
        }
        save();
        return added;
    }
}

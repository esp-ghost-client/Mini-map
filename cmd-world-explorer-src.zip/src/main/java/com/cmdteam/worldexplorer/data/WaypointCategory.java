package com.cmdteam.worldexplorer.data;

public enum WaypointCategory {
    CUSTOM("Custom"),
    DEATH("Death Point"),
    END_CITY("End City"),
    END_SHIP("End Ship");

    public final String label;

    WaypointCategory(String label) {
        this.label = label;
    }

    public static WaypointCategory parse(String s) {
        try {
            return valueOf(s);
        } catch (Exception e) {
            return CUSTOM;
        }
    }
}

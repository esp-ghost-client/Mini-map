package com.cmdteam.worldexplorer.data;

import com.cmdteam.worldexplorer.CmdWorldExplorerClient;

import java.io.*;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.*;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;
import java.util.stream.Stream;
import java.util.zip.GZIPInputStream;
import java.util.zip.GZIPOutputStream;

/**
 * Explored terrain colours the client has really seen, per world and per dimension.
 * Each chunk = 256 ARGB ints (0 = unknown). Saved as gzip files under config/cmd_world_explorer/maps.
 */
public final class MapStore {
    private static final int MAGIC = 0x434D4431; // "CMD1"
    private static final Map<String, Map<Long, int[]>> DIMS = new HashMap<>();
    private static final Set<String> DIRTY = new HashSet<>();
    private static String world = "";
    private static long version = 0;
    private static final ExecutorService IO = Executors.newSingleThreadExecutor(r -> {
        Thread t = new Thread(r, "CMD-WorldExplorer-IO");
        t.setDaemon(true);
        return t;
    });

    private MapStore() {}

    public static long version() {
        return version;
    }

    public static long key(int cx, int cz) {
        return ((long) cx << 32) | (cz & 0xFFFFFFFFL);
    }

    public static void setWorld(String w) {
        if (w.equals(world)) return;
        flush(false);
        DIMS.clear();
        DIRTY.clear();
        world = w;
        version++;
    }

    private static Path file(String dim) {
        return Storage.mapsDir().resolve(world).resolve(dim + ".cmdmap");
    }

    public static Map<Long, int[]> dim(String dimKey) {
        Map<Long, int[]> m = DIMS.get(dimKey);
        if (m == null) {
            m = load(dimKey);
            DIMS.put(dimKey, m);
        }
        return m;
    }

    private static Map<Long, int[]> load(String dimKey) {
        Map<Long, int[]> m = new HashMap<>();
        if (world.isEmpty()) return m;
        Path f = file(dimKey);
        if (!Files.isRegularFile(f)) return m;
        try (DataInputStream in = new DataInputStream(new BufferedInputStream(new GZIPInputStream(Files.newInputStream(f))))) {
            if (in.readInt() != MAGIC) throw new IOException("bad magic");
            int n = in.readInt();
            if (n < 0 || n > 1_000_000) throw new IOException("bad count");
            for (int i = 0; i < n; i++) {
                long k = in.readLong();
                int[] a = new int[256];
                for (int j = 0; j < 256; j++) a[j] = in.readInt();
                m.put(k, a);
            }
        } catch (Exception e) {
            CmdWorldExplorerClient.LOGGER.warn("[CMD] Map file {} is damaged, starting this dimension fresh", f, e);
            Storage.quarantine(f);
            m.clear();
        }
        return m;
    }

    public static int[] chunk(String dim, int cx, int cz) {
        return dim(dim).get(key(cx, cz));
    }

    public static int colorAt(String dim, int x, int z) {
        int[] a = chunk(dim, x >> 4, z >> 4);
        return a == null ? 0 : a[((z & 15) << 4) | (x & 15)];
    }

    public static void put(String dim, int cx, int cz, int[] colors) {
        Map<Long, int[]> m = dim(dim);
        long k = key(cx, cz);
        int[] old = m.get(k);
        if (old == null && m.size() >= ModConfig.get().maxChunks) return;
        if (old != null && Arrays.equals(old, colors)) return;
        m.put(k, colors); // arrays are replaced, never mutated -> safe to snapshot for async saving
        DIRTY.add(dim);
        version++;
    }

    public static int chunkCount(String dim) {
        return dim(dim).size();
    }

    public static boolean hasDirty() {
        return !DIRTY.isEmpty();
    }

    /** Writes changed dimensions to disk. sync=true waits (used on game exit). */
    public static void flush(boolean sync) {
        if (world.isEmpty() || DIRTY.isEmpty()) return;
        List<java.util.concurrent.Future<?>> jobs = new ArrayList<>();
        for (String d : new ArrayList<>(DIRTY)) {
            Map<Long, int[]> m = DIMS.get(d);
            if (m == null) continue;
            Map<Long, int[]> snap = new HashMap<>(m);
            Path f = file(d);
            jobs.add(IO.submit(() -> write(f, snap)));
        }
        DIRTY.clear();
        if (sync) {
            for (var j : jobs) {
                try {
                    j.get(10, TimeUnit.SECONDS);
                } catch (Exception ignored) {
                }
            }
        }
    }

    private static void write(Path f, Map<Long, int[]> snap) {
        try {
            Files.createDirectories(f.getParent());
            Path tmp = f.resolveSibling(f.getFileName() + ".tmp");
            try (DataOutputStream out = new DataOutputStream(new BufferedOutputStream(new GZIPOutputStream(Files.newOutputStream(tmp))))) {
                out.writeInt(MAGIC);
                out.writeInt(snap.size());
                for (Map.Entry<Long, int[]> e : snap.entrySet()) {
                    out.writeLong(e.getKey());
                    for (int c : e.getValue()) out.writeInt(c);
                }
            }
            Storage.moveReplace(tmp, f);
        } catch (Exception e) {
            CmdWorldExplorerClient.LOGGER.warn("[CMD] Could not save map {}", f, e);
        }
    }

    public static void clearDimension(String dim) {
        DIMS.put(dim, new HashMap<>());
        DIRTY.remove(dim);
        try {
            Files.deleteIfExists(file(dim));
        } catch (IOException ignored) {
        }
        version++;
    }

    public static void clearWorld() {
        DIMS.clear();
        DIRTY.clear();
        if (!world.isEmpty()) {
            try (Stream<Path> s = Files.list(Storage.mapsDir().resolve(world))) {
                s.forEach(p -> {
                    try {
                        Files.deleteIfExists(p);
                    } catch (IOException ignored) {
                    }
                });
            } catch (IOException ignored) {
            }
        }
        version++;
    }
}

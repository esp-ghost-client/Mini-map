package com.cmdteam.worldexplorer.ui;

import com.cmdteam.worldexplorer.data.*;
import com.cmdteam.worldexplorer.util.Geo;
import net.minecraft.Util;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.components.EditBox;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.input.MouseButtonEvent;
import net.minecraft.network.chat.Component;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/** Create / edit dialog: name, X Y Z, colour, icon, category, dimension, SAVE / CANCEL. */
public class WaypointEditScreen extends Screen {
    private static final int[] COLORS = {0xA855F7, 0xEF4444, 0xFFFFFF, 0x22C55E, 0x3B82F6, 0xF59E0B,
            0xEC4899, 0x14B8A6, 0xF97316, 0xEAB308, 0x94A3B8, 0x8B5CF6};

    private final Screen parent;
    private final Waypoint wp;
    private final boolean isNew;
    private final long openedAt = Util.getMillis();

    private String name, xs, ys, zs, hex, icon, dimension;
    private int color;
    private WaypointCategory cat;
    private String lastDefaultName;
    private final List<String> dims = new ArrayList<>();
    private boolean confirmDelete;

    private EditBox nameBox, xBox, yBox, zBox, hexBox;
    private Button catBtn, dimBtn, deleteBtn;
    private int panX, panY, panW, panH, swX, swY, icX, icY;

    public WaypointEditScreen(Screen parent, Waypoint wp, boolean isNew) {
        super(Component.literal(isNew ? "New Waypoint" : "Edit Waypoint"));
        this.parent = parent;
        this.wp = wp;
        this.isNew = isNew;
        name = wp.name;
        lastDefaultName = wp.name;
        xs = String.valueOf(wp.x);
        ys = String.valueOf(wp.y);
        zs = String.valueOf(wp.z);
        color = wp.color;
        hex = String.format(Locale.ROOT, "#%06X", color & 0xFFFFFF);
        icon = wp.icon;
        cat = wp.cat();
        dimension = wp.dimension;
        dims.add("overworld");
        dims.add("the_nether");
        dims.add("the_end");
        if (!dims.contains(dimension)) dims.add(dimension);
    }

    @Override
    protected void init() {
        panW = Math.min(width - 10, 380);
        panH = Math.min(height - 10, 190);
        panX = (width - panW) / 2;
        panY = (height - panH) / 2;
        int lx = panX + 10, lw = 170, rx = panX + 195;

        nameBox = new EditBox(font, lx, panY + 28, lw, 18, Component.literal("Waypoint Name"));
        nameBox.setMaxLength(48);
        nameBox.setValue(name);
        nameBox.setHint(Component.literal("Waypoint Name"));
        nameBox.setResponder(s -> name = s);
        addRenderableWidget(nameBox);

        int cw = 54;
        xBox = coordBox(lx, panY + 64, cw, xs, "X", s -> xs = s);
        yBox = coordBox(lx + cw + 4, panY + 64, cw, ys, "Y", s -> ys = s);
        zBox = coordBox(lx + 2 * (cw + 4), panY + 64, cw, zs, "Z", s -> zs = s);

        catBtn = addRenderableWidget(Button.builder(Component.literal(""), b -> cycleCategory())
                .bounds(lx, panY + 90, lw, 18).build());
        dimBtn = addRenderableWidget(Button.builder(Component.literal(""), b -> cycleDimension())
                .bounds(lx, panY + 112, lw, 18).build());
        refreshLabels();

        swX = rx;
        swY = panY + 28;
        hexBox = new EditBox(font, rx, panY + 66, 70, 16, Component.literal("Hex"));
        hexBox.setMaxLength(7);
        hexBox.setFilter(s -> s.matches("#?[0-9a-fA-F]{0,6}"));
        hexBox.setValue(hex);
        hexBox.setResponder(s -> {
            hex = s;
            String h = s.startsWith("#") ? s.substring(1) : s;
            if (h.length() == 6) {
                try {
                    color = Integer.parseInt(h, 16);
                } catch (NumberFormatException ignored) {
                }
            }
        });
        addRenderableWidget(hexBox);
        icX = rx;
        icY = panY + 100;

        int by = panY + panH - 26;
        int bw = isNew ? (panW - 20 - 4) / 2 : (panW - 20 - 8) / 3;
        addRenderableWidget(Button.builder(Component.literal("SAVE"), b -> save())
                .bounds(panX + 10, by, bw, 20).build());
        addRenderableWidget(Button.builder(Component.literal("CANCEL"), b -> onClose())
                .bounds(panX + 14 + bw, by, bw, 20).build());
        if (!isNew) {
            deleteBtn = addRenderableWidget(Button.builder(Component.literal("DELETE"), b -> delete())
                    .bounds(panX + 18 + 2 * bw, by, bw, 20).build());
        }
    }

    private EditBox coordBox(int x, int y, int w, String value, String hint, java.util.function.Consumer<String> sink) {
        EditBox b = new EditBox(font, x, y, w, 18, Component.literal(hint));
        b.setMaxLength(10);
        b.setFilter(s -> s.matches("-?\\d{0,9}"));
        b.setValue(value);
        b.setHint(Component.literal(hint));
        b.setResponder(sink);
        return addRenderableWidget(b);
    }

    private void refreshLabels() {
        catBtn.setMessage(Component.literal("Type: " + cat.label));
        catBtn.active = cat != WaypointCategory.DEATH;
        dimBtn.setMessage(Component.literal("Dimension: " + Dims.pretty(dimension)));
    }

    private void cycleCategory() {
        WaypointCategory[] opts = {WaypointCategory.CUSTOM, WaypointCategory.END_CITY, WaypointCategory.END_SHIP};
        int i = 0;
        for (int k = 0; k < opts.length; k++) if (opts[k] == cat) i = k;
        cat = opts[(i + 1) % opts.length];
        if (isNew) {
            Waypoint d = Waypoint.create(cat, "", "", 0, 0, 0);
            boolean untouched = name.isEmpty() || name.equals(lastDefaultName);
            if (untouched) {
                name = d.name;
                nameBox.setValue(name);
            }
            lastDefaultName = d.name;
            icon = d.icon;
            color = d.color;
            hexBox.setValue(String.format(Locale.ROOT, "#%06X", color));
        }
        refreshLabels();
    }

    private void cycleDimension() {
        int i = dims.indexOf(dimension);
        dimension = dims.get((i + 1) % dims.size());
        refreshLabels();
    }

    private void save() {
        String n = name.trim();
        wp.name = n.isEmpty() ? "Waypoint" : n;
        wp.x = Geo.parseInt(xs);
        wp.y = Geo.parseInt(ys);
        wp.z = Geo.parseInt(zs);
        wp.dimension = dimension;
        wp.color = color & 0xFFFFFF;
        wp.icon = icon;
        wp.category = cat.name();
        if (isNew) WaypointManager.add(wp);
        else WaypointManager.save();
        minecraft.setScreen(parent);
    }

    private void delete() {
        if (!confirmDelete) {
            confirmDelete = true;
            deleteBtn.setMessage(Component.literal("SURE?"));
            return;
        }
        WaypointManager.remove(wp);
        minecraft.setScreen(parent);
    }

    @Override
    public void onClose() {
        minecraft.setScreen(parent);
    }

    @Override
    public boolean mouseClicked(MouseButtonEvent event, boolean doubleClick) {
        if (super.mouseClicked(event, doubleClick)) return true;
        double mx = event.x(), my = event.y();
        for (int i = 0; i < COLORS.length; i++) {
            int x = swX + (i % 6) * 19, y = swY + (i / 6) * 19;
            if (mx >= x && mx < x + 16 && my >= y && my < y + 16) {
                color = COLORS[i];
                hexBox.setValue(String.format(Locale.ROOT, "#%06X", color));
                return true;
            }
        }
        WaypointIcon[] icons = WaypointIcon.values();
        for (int i = 0; i < icons.length; i++) {
            int x = icX + (i % 5) * 24, y = icY + (i / 5) * 22;
            if (mx >= x && mx < x + 20 && my >= y && my < y + 20) {
                icon = icons[i].name();
                return true;
            }
        }
        return false;
    }

    @Override
    public void renderBackground(GuiGraphics g, int mx, int my, float pt) {
    }

    @Override
    public void render(GuiGraphics g, int mx, int my, float pt) {
        g.fill(0, 0, width, height, 0xC8000000);
        UiTheme.panel(g, panX, panY, panW, panH);
        UiTheme.title(g, font, isNew ? "NEW WAYPOINT" : "EDIT WAYPOINT", panX + 10, panY + 8);
        g.drawString(font, "Waypoint Name", panX + 10, panY + 18, UiTheme.GRAY, false);
        g.drawString(font, "X            Y            Z", panX + 14, panY + 53, UiTheme.GRAY, false);
        g.drawString(font, "Color", swX, panY + 18, UiTheme.GRAY, false);
        g.drawString(font, "Icon", icX, icY - 10, UiTheme.GRAY, false);
        for (int i = 0; i < COLORS.length; i++) {
            int x = swX + (i % 6) * 19, y = swY + (i / 6) * 19;
            g.fill(x, y, x + 16, y + 16, 0xFF000000 | COLORS[i]);
            if ((color & 0xFFFFFF) == COLORS[i]) UiTheme.border(g, x - 1, y - 1, 18, 18, UiTheme.WHITE);
        }
        WaypointIcon[] icons = WaypointIcon.values();
        for (int i = 0; i < icons.length; i++) {
            int x = icX + (i % 5) * 24, y = icY + (i / 5) * 22;
            g.fill(x, y, x + 20, y + 20, UiTheme.PANEL_LIGHT);
            icons[i].drawShadowed(g, x + 3, y + 3, 2, color);
            if (icons[i].name().equals(icon)) UiTheme.border(g, x, y, 20, 20, UiTheme.PURPLE);
        }
        super.render(g, mx, my, pt);
        UiTheme.fadeOverlay(g, width, height, openedAt);
    }
}

package com.cmdteam.worldexplorer.ui;

import com.cmdteam.worldexplorer.data.*;
import com.cmdteam.worldexplorer.util.Geo;
import net.minecraft.Util;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.components.EditBox;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.input.MouseButtonEvent;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.network.chat.Component;
import net.minecraft.util.Mth;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Locale;

/** All waypoints with tabs, search, sort by distance, rename/icon/colour edit, delete, navigate, copy. */
public class WaypointManagerScreen extends Screen {
    private static final int ROW = 26;
    private static final String[] TABS = {"All", "End Cities", "End Ships", "Death Points", "Custom"};

    private final Screen parent;
    private final long openedAt = Util.getMillis();
    private int tab = 0;
    private int sort = 0; // 0 distance, 1 name, 2 newest
    private String query = "";
    private List<Waypoint> rows = new ArrayList<>();
    private Waypoint selected;
    private double scroll;
    private boolean pressing, moved;
    private double pressY, scrollStart;
    private boolean confirmDelete;
    private int lx, ly, lw, lh;
    private Button navBtn, editBtn, copyBtn, delBtn, sortBtn;

    public WaypointManagerScreen(Screen parent) {
        super(Component.literal("Waypoint Manager"));
        this.parent = parent;
    }

    @Override
    protected void init() {
        int tw = (width - 16 - 4 * 3) / 5;
        for (int i = 0; i < TABS.length; i++) {
            final int idx = i;
            Button b = Button.builder(Component.literal(TABS[i]), x -> {
                tab = idx;
                scroll = 0;
                rebuildWidgets();
            }).bounds(8 + i * (tw + 3), 20, tw, 18).build();
            b.active = tab != i;
            addRenderableWidget(b);
        }
        int sw = 104;
        EditBox search = new EditBox(font, 8, 42, width - 16 - sw - 4, 18, Component.literal("Search"));
        search.setMaxLength(48);
        search.setHint(Component.literal("Search by name..."));
        search.setValue(query);
        search.setResponder(s -> {
            query = s;
            scroll = 0;
            refresh();
        });
        addRenderableWidget(search);
        sortBtn = addRenderableWidget(Button.builder(Component.literal(""), b -> {
            sort = (sort + 1) % 3;
            refresh();
        }).bounds(width - 8 - sw, 42, sw, 18).build());

        lx = 8;
        ly = 64;
        lw = width - 16;
        lh = Math.max(ROW, height - ly - 32);

        int bw = (width - 16 - 5 * 3) / 6, by = height - 26;
        addRenderableWidget(Button.builder(Component.literal("New"), b -> createNew()).bounds(8, by, bw, 20).build());
        navBtn = addRenderableWidget(Button.builder(Component.literal("Navigate"), b -> navigate())
                .bounds(8 + (bw + 3), by, bw, 20).build());
        editBtn = addRenderableWidget(Button.builder(Component.literal("Edit"), b -> edit())
                .bounds(8 + 2 * (bw + 3), by, bw, 20).build());
        copyBtn = addRenderableWidget(Button.builder(Component.literal("Copy"), b -> copy())
                .bounds(8 + 3 * (bw + 3), by, bw, 20).build());
        delBtn = addRenderableWidget(Button.builder(Component.literal("Delete"), b -> delete())
                .bounds(8 + 4 * (bw + 3), by, bw, 20).build());
        addRenderableWidget(Button.builder(Component.literal("Done"), b -> onClose())
                .bounds(8 + 5 * (bw + 3), by, bw, 20).build());
        refresh();
    }

    private void refresh() {
        Minecraft mc = Minecraft.getInstance();
        LocalPlayer p = mc.player;
        String curDim = mc.level == null ? "" : Dims.key(mc.level);
        String q = query.trim().toLowerCase(Locale.ROOT);
        List<Waypoint> out = new ArrayList<>();
        for (Waypoint w : WaypointManager.current()) {
            WaypointCategory c = w.cat();
            boolean ok = switch (tab) {
                case 1 -> c == WaypointCategory.END_CITY;
                case 2 -> c == WaypointCategory.END_SHIP;
                case 3 -> c == WaypointCategory.DEATH;
                case 4 -> c == WaypointCategory.CUSTOM;
                default -> true;
            };
            if (ok && (q.isEmpty() || w.name.toLowerCase(Locale.ROOT).contains(q))) out.add(w);
        }
        Comparator<Waypoint> byName = Comparator.comparing(w -> w.name.toLowerCase(Locale.ROOT));
        switch (sort) {
            case 0 -> out.sort(Comparator.comparingDouble((Waypoint w) ->
                    p != null && w.dimension.equals(curDim) ? w.distanceTo(p.getX(), p.getY(), p.getZ()) : Double.MAX_VALUE)
                    .thenComparing(byName));
            case 1 -> out.sort(byName);
            default -> out.sort(Comparator.comparingLong((Waypoint w) -> w.createdAt).reversed());
        }
        rows = out;
        if (selected != null && !rows.contains(selected)) selected = null;
        clampScroll();
        sortBtn.setMessage(Component.literal("Sort: " + new String[]{"Distance", "Name", "Newest"}[sort]));
        updateButtons();
    }

    private void updateButtons() {
        boolean has = selected != null;
        navBtn.active = has;
        editBtn.active = has;
        copyBtn.active = has;
        delBtn.active = has;
        delBtn.setMessage(Component.literal(confirmDelete ? "Sure?" : "Delete"));
        Waypoint nav = WaypointManager.navTarget();
        navBtn.setMessage(Component.literal(has && nav != null && nav.id.equals(selected.id) ? "Stop nav" : "Navigate"));
    }

    private void clampScroll() {
        scroll = Mth.clamp(scroll, 0, Math.max(0, rows.size() * ROW - lh));
    }

    private void createNew() {
        Minecraft mc = Minecraft.getInstance();
        LocalPlayer p = mc.player;
        if (p == null || mc.level == null) return;
        WaypointCategory c = switch (tab) {
            case 1 -> WaypointCategory.END_CITY;
            case 2 -> WaypointCategory.END_SHIP;
            default -> WaypointCategory.CUSTOM;
        };
        Waypoint w = Waypoint.create(c, WaypointManager.world(), Dims.key(mc.level), p.getBlockX(), p.getBlockY(), p.getBlockZ());
        mc.setScreen(new WaypointEditScreen(this, w, true));
    }

    private void navigate() {
        if (selected == null) return;
        Waypoint nav = WaypointManager.navTarget();
        if (nav != null && nav.id.equals(selected.id)) WaypointManager.setNav(null);
        else WaypointManager.setNav(selected);
        updateButtons();
    }

    private void edit() {
        if (selected != null) minecraft.setScreen(new WaypointEditScreen(this, selected, false));
    }

    private void copy() {
        if (selected != null) Geo.copy(selected.x + " " + selected.y + " " + selected.z);
    }

    private void delete() {
        if (selected == null) return;
        if (!confirmDelete) {
            confirmDelete = true;
            updateButtons();
            return;
        }
        WaypointManager.remove(selected);
        selected = null;
        confirmDelete = false;
        refresh();
    }

    @Override
    public void onClose() {
        minecraft.setScreen(parent);
    }

    private boolean inList(double mx, double my) {
        return mx >= lx && mx < lx + lw && my >= ly && my < ly + lh;
    }

    @Override
    public boolean mouseClicked(MouseButtonEvent event, boolean doubleClick) {
        if (super.mouseClicked(event, doubleClick)) return true;
        if (event.button() == 0 && inList(event.x(), event.y())) {
            pressing = true;
            moved = false;
            pressY = event.y();
            scrollStart = scroll;
            return true;
        }
        return false;
    }

    @Override
    public boolean mouseDragged(MouseButtonEvent event, double dx, double dy) {
        if (pressing) {
            if (Math.abs(event.y() - pressY) > 4) moved = true;
            if (moved) {
                scroll = scrollStart - (event.y() - pressY);
                clampScroll();
            }
            return true;
        }
        return super.mouseDragged(event, dx, dy);
    }

    @Override
    public boolean mouseReleased(MouseButtonEvent event) {
        if (pressing) {
            pressing = false;
            if (!moved && inList(event.x(), event.y())) {
                int idx = (int) ((event.y() - ly + scroll) / ROW);
                selected = idx >= 0 && idx < rows.size() ? rows.get(idx) : null;
                confirmDelete = false;
                updateButtons();
            }
            return true;
        }
        return super.mouseReleased(event);
    }

    @Override
    public boolean mouseScrolled(double mx, double my, double hx, double vy) {
        scroll -= vy * ROW;
        clampScroll();
        return true;
    }

    @Override
    public void renderBackground(GuiGraphics g, int mx, int my, float pt) {
    }

    @Override
    public void render(GuiGraphics g, int mx, int my, float pt) {
        g.fill(0, 0, width, height, UiTheme.BG);
        UiTheme.title(g, font, "WAYPOINT MANAGER", 8, 6);
        String cnt = rows.size() + " shown";
        g.drawString(font, cnt, width - 8 - font.width(cnt), 6, UiTheme.GRAY, true);

        g.fill(lx, ly, lx + lw, ly + lh, UiTheme.PANEL);
        UiTheme.border(g, lx, ly, lw, lh, UiTheme.PURPLE_DARK);
        Minecraft mc = Minecraft.getInstance();
        LocalPlayer p = mc.player;
        String curDim = mc.level == null ? "" : Dims.key(mc.level);
        Waypoint nav = WaypointManager.navTarget();
        g.enableScissor(lx + 1, ly + 1, lx + lw - 1, ly + lh - 1);
        for (int i = 0; i < rows.size(); i++) {
            int y = ly - (int) scroll + i * ROW;
            if (y + ROW < ly || y > ly + lh) continue;
            Waypoint w = rows.get(i);
            if (w == selected) g.fill(lx + 1, y, lx + lw - 1, y + ROW - 1, 0xFF2E2150);
            else if (i % 2 == 1) g.fill(lx + 1, y, lx + lw - 1, y + ROW - 1, 0x14FFFFFF);
            w.iconType().drawShadowed(g, lx + 6, y + 6, 2, w.color);
            String n = Geo.shorten(w.name, Math.max(8, (lw - 90) / 6));
            g.drawString(font, n, lx + 26, y + 4, UiTheme.WHITE, true);
            boolean same = w.dimension.equals(curDim);
            String dist = same && p != null ? Geo.fmtDist(w.distanceTo(p.getX(), p.getY(), p.getZ())) : "-";
            String line = w.coords() + "  |  " + dist + "  |  " + Dims.pretty(w.dimension);
            g.drawString(font, line, lx + 26, y + 15, same ? UiTheme.GRAY : 0xFF6B7280, false);
            if (nav != null && nav.id.equals(w.id)) {
                g.drawString(font, "NAV", lx + lw - 24, y + 4, UiTheme.PURPLE, true);
            }
        }
        g.disableScissor();
        if (rows.isEmpty()) {
            String s = "No waypoints here yet. Press New, or long-press / Shift+Right-click on the map.";
            g.drawString(font, Geo.shorten(s, Math.max(10, lw / 6)), lx + 8, ly + 10, UiTheme.GRAY, false);
        }
        int total = rows.size() * ROW;
        if (total > lh) {
            int bh = Math.max(12, lh * lh / total);
            int by = ly + (int) ((lh - bh) * (scroll / (total - lh)));
            g.fill(lx + lw - 3, by, lx + lw - 1, by + bh, UiTheme.PURPLE);
        }
        super.render(g, mx, my, pt);
        UiTheme.fadeOverlay(g, width, height, openedAt);
    }
}

package com.cmdteam.worldexplorer.ui;

import com.cmdteam.worldexplorer.data.*;
import com.cmdteam.worldexplorer.map.MapDraw;
import com.cmdteam.worldexplorer.util.Geo;
import net.minecraft.Util;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.input.MouseButtonEvent;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.network.chat.Component;
import net.minecraft.util.Mth;
import org.lwjgl.glfw.GLFW;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/**
 * Full-screen explored map.
 * Mouse: left-click = select, right-click = location info, Shift+right-click = new waypoint, wheel = zoom, drag = pan.
 * Touch: tap = select, hold = new waypoint, drag = pan, buttons for everything else.
 */
public class MapScreen extends Screen {
    private static final int TOP = 16, BOTTOM = 28, PANEL_H = 44;

    private final MapDraw.TerrainCache cache = new MapDraw.TerrainCache();
    private final long openedAt = Util.getMillis();
    private double cx, cz;
    private int zoom;
    private Integer selX, selZ;
    private Waypoint selWp;
    private boolean infoExpanded, confirmDelete;
    private boolean pressing, moved, longDone;
    private long pressAt;
    private double pressX, pressY;
    private final List<Button> locButtons = new ArrayList<>();
    private final List<Button> wpButtons = new ArrayList<>();
    private Button deleteBtn;
    private MapDraw.View view;

    public MapScreen() {
        super(Component.literal("CMD World Explorer"));
        LocalPlayer p = Minecraft.getInstance().player;
        if (p != null) {
            cx = p.getX();
            cz = p.getZ();
        }
        zoom = ModConfig.get().mapZoomIndex;
    }

    @Override
    protected void init() {
        locButtons.clear();
        wpButtons.clear();
        int bw = (width - 8 - 5 * 3) / 6;
        int by = height - 24;
        String[] labels = {"-", "+", "Center", "Waypoints", "Settings", "Close"};
        Runnable[] acts = {() -> zoomBy(1), () -> zoomBy(-1), this::center,
                () -> minecraft.setScreen(new WaypointManagerScreen(this)),
                () -> minecraft.setScreen(new SettingsScreen(this)), this::onClose};
        for (int i = 0; i < 6; i++) {
            final Runnable a = acts[i];
            addRenderableWidget(Button.builder(Component.literal(labels[i]), b -> a.run())
                    .bounds(4 + i * (bw + 3), by, bw, 20).build());
        }
        int pw = Math.min(width - 8, 420);
        int px = (width - pw) / 2;
        int py = height - BOTTOM - PANEL_H + 22;
        int n = 5, w5 = (pw - 8 - (n - 1) * 3) / n;
        String[] l1 = {"Create", "End City", "End Ship", "Navigate", "Copy"};
        Runnable[] a1 = {() -> openDialog(WaypointCategory.CUSTOM), () -> openDialog(WaypointCategory.END_CITY),
                () -> openDialog(WaypointCategory.END_SHIP), this::navigateHere, this::copyLoc};
        for (int i = 0; i < n; i++) {
            final Runnable a = a1[i];
            Button b = Button.builder(Component.literal(l1[i]), x -> a.run())
                    .bounds(px + 4 + i * (w5 + 3), py, w5, 18).build();
            locButtons.add(addRenderableWidget(b));
        }
        int m = 4, w4 = (pw - 8 - (m - 1) * 3) / m;
        String[] l2 = {"Edit", "Navigate", "Copy", "Delete"};
        Runnable[] a2 = {this::editWp, this::navigateWp, this::copyLoc, this::deleteWp};
        for (int i = 0; i < m; i++) {
            final Runnable a = a2[i];
            Button b = Button.builder(Component.literal(l2[i]), x -> a.run())
                    .bounds(px + 4 + i * (w4 + 3), py, w4, 18).build();
            wpButtons.add(addRenderableWidget(b));
            if (i == 3) deleteBtn = b;
        }
        updateButtons();
    }

    private void updateButtons() {
        for (Button b : locButtons) b.visible = selX != null && selWp == null;
        for (Button b : wpButtons) b.visible = selWp != null;
        if (deleteBtn != null) deleteBtn.setMessage(Component.literal(confirmDelete ? "Sure?" : "Delete"));
    }

    private boolean panelShown() {
        return selWp != null || selX != null;
    }

    private void zoomBy(int d) {
        zoom = Mth.clamp(zoom + d, 0, MapDraw.ZOOMS.length - 1);
        ModConfig.get().mapZoomIndex = zoom;
    }

    private void center() {
        LocalPlayer p = minecraft.player;
        if (p != null) {
            cx = p.getX();
            cz = p.getZ();
        }
    }

    private String dim() {
        return Dims.key(minecraft.level);
    }

    private void openDialog(WaypointCategory cat) {
        if (selX == null) return;
        openDialogAt(selX, selZ, cat);
    }

    private void openDialogAt(int x, int z, WaypointCategory cat) {
        LocalPlayer p = minecraft.player;
        int y = Geo.surfaceY(minecraft.level, p, x, z);
        Waypoint w = Waypoint.create(cat, WaypointManager.world(), dim(), x, y, z);
        minecraft.setScreen(new WaypointEditScreen(this, w, true));
    }

    private void navigateHere() {
        if (selX == null) return;
        int y = Geo.surfaceY(minecraft.level, minecraft.player, selX, selZ);
        WaypointManager.setTemp(dim(), selX, y, selZ);
    }

    private void navigateWp() {
        if (selWp != null) WaypointManager.setNav(selWp);
    }

    private void copyLoc() {
        if (selWp != null) Geo.copy(selWp.x + " " + selWp.y + " " + selWp.z);
        else if (selX != null) Geo.copy(selX + " " + Geo.surfaceY(minecraft.level, minecraft.player, selX, selZ) + " " + selZ);
    }

    private void editWp() {
        if (selWp != null) minecraft.setScreen(new WaypointEditScreen(this, selWp, false));
    }

    private void deleteWp() {
        if (selWp == null) return;
        if (!confirmDelete) {
            confirmDelete = true;
            updateButtons();
            return;
        }
        WaypointManager.remove(selWp);
        selWp = null;
        confirmDelete = false;
        updateButtons();
    }

    private Waypoint hitWaypoint(double mx, double my) {
        Waypoint best = null;
        double bd = 36;
        String d = dim();
        for (Waypoint w : WaypointManager.current()) {
            if (!w.dimension.equals(d)) continue;
            double dx = view.sx(w.x + 0.5) - mx, dy = view.sy(w.z + 0.5) - my;
            double dist = dx * dx + dy * dy;
            if (dist <= bd) {
                bd = dist;
                best = w;
            }
        }
        return best;
    }

    private boolean inMapArea(double mx, double my) {
        if (my < TOP || my >= height - BOTTOM) return false;
        if (panelShown() && my >= height - BOTTOM - PANEL_H) return false;
        return true;
    }

    @Override
    public boolean mouseClicked(MouseButtonEvent event, boolean doubleClick) {
        if (super.mouseClicked(event, doubleClick)) return true;
        double mx = event.x(), my = event.y();
        if (!inMapArea(mx, my) || view == null) return false;
        int btn = event.button();
        if (btn == GLFW.GLFW_MOUSE_BUTTON_LEFT) {
            pressing = true;
            moved = false;
            longDone = false;
            pressAt = Util.getMillis();
            pressX = mx;
            pressY = my;
            return true;
        }
        if (btn == GLFW.GLFW_MOUSE_BUTTON_RIGHT) {
            int bx = (int) Math.floor(view.wx(mx)), bz = (int) Math.floor(view.wz(my));
            if ((event.modifiers() & GLFW.GLFW_MOD_SHIFT) != 0) {
                openDialogAt(bx, bz, WaypointCategory.CUSTOM);
            } else {
                selectLocation(bx, bz);
                infoExpanded = true;
            }
            return true;
        }
        return false;
    }

    private void selectLocation(int bx, int bz) {
        selX = bx;
        selZ = bz;
        selWp = null;
        infoExpanded = false;
        confirmDelete = false;
        updateButtons();
    }

    @Override
    public boolean mouseDragged(MouseButtonEvent event, double dx, double dy) {
        if (pressing && event.button() == GLFW.GLFW_MOUSE_BUTTON_LEFT && view != null) {
            if (!moved && Math.hypot(event.x() - pressX, event.y() - pressY) > 5) moved = true;
            if (moved) {
                cx -= dx * view.bpc / view.cellPx;
                cz -= dy * view.bpc / view.cellPx;
            }
            return true;
        }
        return super.mouseDragged(event, dx, dy);
    }

    @Override
    public boolean mouseReleased(MouseButtonEvent event) {
        if (pressing && event.button() == GLFW.GLFW_MOUSE_BUTTON_LEFT) {
            pressing = false;
            if (!moved && !longDone && view != null) {
                Waypoint hit = hitWaypoint(event.x(), event.y());
                if (hit != null) {
                    selWp = hit;
                    selX = null;
                    selZ = null;
                    confirmDelete = false;
                    updateButtons();
                } else {
                    selectLocation((int) Math.floor(view.wx(event.x())), (int) Math.floor(view.wz(event.y())));
                }
            }
            return true;
        }
        return super.mouseReleased(event);
    }

    @Override
    public boolean mouseScrolled(double mx, double my, double hx, double vy) {
        if (vy != 0) {
            zoomBy(vy > 0 ? -1 : 1);
            return true;
        }
        return super.mouseScrolled(mx, my, hx, vy);
    }

    @Override
    public boolean isPauseScreen() {
        return false;
    }

    @Override
    public void removed() {
        ModConfig.save();
    }

    @Override
    public void renderBackground(GuiGraphics g, int mx, int my, float pt) {
        // custom backdrop is drawn in render(); no blur
    }

    @Override
    public void render(GuiGraphics g, int mx, int my, float pt) {
        String dim = dim();
        g.fill(0, 0, width, height, UiTheme.BG);
        view = new MapDraw.View(0, TOP, width, height - TOP - BOTTOM, cx, cz, zoom);
        cache.ensure(view, dim);
        g.enableScissor(0, TOP, width, height - BOTTOM);
        MapDraw.drawTerrain(g, cache, view, false, 1f);
        MapDraw.drawMarkers(g, view, false, WaypointManager.current(), dim, true, WaypointManager.navTarget());
        LocalPlayer p = minecraft.player;
        if (p != null) MapDraw.drawPlayer(g, view, p.getX(), p.getZ(), p.getYRot());
        if (selX != null) drawPin(g, view.sx(selX + 0.5), view.sy(selZ + 0.5));
        if (selWp != null) drawPin(g, view.sx(selWp.x + 0.5), view.sy(selWp.z + 0.5));
        g.disableScissor();

        if (pressing && !moved && !longDone && Util.getMillis() - pressAt >= ModConfig.get().longPressMs) {
            longDone = true;
            pressing = false;
            openDialogAt((int) Math.floor(view.wx(pressX)), (int) Math.floor(view.wz(pressY)), WaypointCategory.CUSTOM);
            return;
        }

        // top bar
        g.fill(0, 0, width, TOP, 0xE6000000);
        UiTheme.title(g, font, "WORLD EXPLORER", 4, 4);
        String cur = String.format(Locale.ROOT, "X %d  Z %d  |  %s  |  zoom %d/%d", (int) Math.floor(view.wx(mx)),
                (int) Math.floor(view.wz(my)), Dims.pretty(dim), 7 - zoom, MapDraw.ZOOMS.length);
        g.drawString(font, cur, width - font.width(cur) - 4, 4, UiTheme.GRAY, true);
        g.fill(0, height - BOTTOM, width, height, 0xF00B0B10);

        if (panelShown()) drawPanel(g, p);
        super.render(g, mx, my, pt);
        UiTheme.fadeOverlay(g, width, height, openedAt);
    }

    private void drawPin(GuiGraphics g, double sx, double sy) {
        int x = (int) Math.round(sx), y = (int) Math.round(sy);
        int r = 5 + (int) (Math.sin(Util.getMillis() / 200.0) * 1.5);
        int c = 0xFFFFFFFF;
        g.fill(x - r - 3, y, x - r + 1, y + 1, c);
        g.fill(x + r - 1, y, x + r + 3, y + 1, c);
        g.fill(x, y - r - 3, x + 1, y - r + 1, c);
        g.fill(x, y + r - 1, x + 1, y + r + 3, c);
        g.fill(x, y, x + 1, y + 1, UiTheme.RED);
    }

    private void drawPanel(GuiGraphics g, LocalPlayer p) {
        int pw = Math.min(width - 8, 420), px = (width - pw) / 2, py = height - BOTTOM - PANEL_H;
        g.fill(px, py, px + pw, py + PANEL_H - 2, 0xF0101016);
        UiTheme.border(g, px, py, pw, PANEL_H - 2, UiTheme.PURPLE_DARK);
        String dim = dim();
        if (selWp != null) {
            Waypoint w = selWp;
            w.iconType().drawShadowed(g, px + 5, py + 4, 1, w.color);
            g.drawString(font, Geo.shorten(w.name, 40), px + 16, py + 4, UiTheme.WHITE, true);
            boolean same = w.dimension.equals(dim);
            String d = same ? Geo.fmtDist(w.distanceTo(p.getX(), p.getY(), p.getZ())) : "in " + Dims.pretty(w.dimension);
            String s = w.coords() + "  |  " + d;
            g.drawString(font, s, px + 5, py + 14, same ? UiTheme.GRAY : UiTheme.RED, false);
        } else if (selX != null) {
            int y = Geo.surfaceY(minecraft.level, p, selX, selZ);
            g.drawString(font, String.format(Locale.ROOT, "X: %d | Y: %d | Z: %d", selX, y, selZ), px + 5, py + 4, UiTheme.WHITE, true);
            double d = Math.hypot(selX + 0.5 - p.getX(), selZ + 0.5 - p.getZ());
            String s = "Distance: " + Geo.fmtDist(d);
            if (infoExpanded) {
                boolean known = MapStore.colorAt(dim, selX, selZ) != 0;
                s += "  |  Chunk " + (selX >> 4) + ", " + (selZ >> 4) + "  |  " + (known ? "explored" : "unexplored")
                        + "  |  " + Dims.pretty(dim);
            }
            g.drawString(font, s, px + 5, py + 14, UiTheme.GRAY, false);
        }
    }
}

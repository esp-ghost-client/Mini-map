package com.cmdteam.worldexplorer.ui;

import net.minecraft.Util;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.util.Mth;

/** CMD Team dark theme: black/charcoal with purple, red and white accents. */
public final class UiTheme {
    public static final int BG = 0xFF0B0B10;
    public static final int PANEL = 0xFF15151C;
    public static final int PANEL_LIGHT = 0xFF22222E;
    public static final int PURPLE = 0xFF8B5CF6;
    public static final int PURPLE_DARK = 0xFF5B3BB0;
    public static final int RED = 0xFFEF4444;
    public static final int WHITE = 0xFFFFFFFF;
    public static final int GRAY = 0xFF9CA3AF;
    public static final int GREEN = 0xFF4ADE80;

    private UiTheme() {}

    public static void border(GuiGraphics g, int x, int y, int w, int h, int c) {
        g.fill(x, y, x + w, y + 1, c);
        g.fill(x, y + h - 1, x + w, y + h, c);
        g.fill(x, y, x + 1, y + h, c);
        g.fill(x + w - 1, y, x + w, y + h, c);
    }

    public static void panel(GuiGraphics g, int x, int y, int w, int h) {
        g.fill(x, y, x + w, y + h, PANEL);
        border(g, x, y, w, h, PURPLE_DARK);
    }

    public static void title(GuiGraphics g, Font f, String text, int x, int y) {
        g.drawString(f, "CMD", x, y, PURPLE, true);
        g.drawString(f, text, x + f.width("CMD") + 5, y, WHITE, true);
    }

    /** 0..1 over ~180 ms, for fade-in animations. */
    public static float fade(long openedAt) {
        return Mth.clamp((Util.getMillis() - openedAt) / 180f, 0f, 1f);
    }

    public static void fadeOverlay(GuiGraphics g, int w, int h, long openedAt) {
        float f = fade(openedAt);
        if (f >= 1f) return;
        g.fill(0, 0, w, h, ((int) ((1f - f) * 255) & 255) << 24);
    }

    public static int withAlpha(int rgb, float a) {
        return (((int) (Mth.clamp(a, 0f, 1f) * 255)) << 24) | (rgb & 0xFFFFFF);
    }
}

package com.cmdteam.worldexplorer.ui;

import com.cmdteam.worldexplorer.data.*;
import com.cmdteam.worldexplorer.map.MinimapRenderer;
import net.minecraft.Util;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.AbstractSliderButton;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.input.MouseButtonEvent;
import net.minecraft.network.chat.Component;
import net.minecraft.util.Mth;

import java.nio.file.Files;
import java.nio.file.Path;
import java.util.function.BooleanSupplier;
import java.util.function.Consumer;
import java.util.function.DoubleConsumer;
import java.util.function.DoubleFunction;

/** Minimap / Map / Controls / Data settings. In the Minimap tab you can drag the minimap preview to move it. */
public class SettingsScreen extends Screen {
    private static final String[] TABS = {"Minimap", "Map", "Controls", "Data"};
    private static final int[] RADII = {3, 4, 5, 6, 8};
    private static final int[] MAXCH = {5000, 10000, 20000, 40000};
    private static final int[] DEATHS = {5, 10, 20, 50};

    private final Screen parent;
    private final long openedAt = Util.getMillis();
    private int tab = 0;
    private boolean dragging;
    private int dragOffX, dragOffY;
    private int[] mm = {0, 0, 0, 0};
    private String status = "";
    private boolean confirmDim, confirmWorld, confirmDeaths;

    public SettingsScreen(Screen parent) {
        super(Component.literal("CMD World Explorer Settings"));
        this.parent = parent;
    }

    private static final class Slider extends AbstractSliderButton {
        private final double min, max;
        private final DoubleConsumer onChange;
        private final DoubleFunction<String> label;

        Slider(int x, int y, int w, double min, double max, double cur, DoubleFunction<String> label, DoubleConsumer onChange) {
            super(x, y, w, 20, Component.empty(), (cur - min) / (max - min));
            this.min = min;
            this.max = max;
            this.label = label;
            this.onChange = onChange;
            updateMessage();
        }

        private double real() {
            return min + (max - min) * this.value;
        }

        @Override
        protected void updateMessage() {
            if (label == null) return;
            setMessage(Component.literal(label.apply(real())));
        }

        @Override
        protected void applyValue() {
            onChange.accept(real());
        }
    }

    private Button toggle(int x, int y, int w, String label, BooleanSupplier get, Consumer<Boolean> set) {
        Button b = Button.builder(Component.literal(label + ": " + (get.getAsBoolean() ? "ON" : "OFF")), btn -> {
            set.accept(!get.getAsBoolean());
            btn.setMessage(Component.literal(label + ": " + (get.getAsBoolean() ? "ON" : "OFF")));
        }).bounds(x, y, w, 20).build();
        return addRenderableWidget(b);
    }

    private Button action(int x, int y, int w, String label, Runnable r) {
        return addRenderableWidget(Button.builder(Component.literal(label), b -> r.run()).bounds(x, y, w, 20).build());
    }

    private static int next(int[] opts, int cur) {
        for (int i = 0; i < opts.length; i++) if (opts[i] == cur) return opts[(i + 1) % opts.length];
        return opts[0];
    }

    @Override
    protected void init() {
        ModConfig c = ModConfig.get();
        int tw = 76;
        for (int i = 0; i < TABS.length; i++) {
            final int idx = i;
            Button b = Button.builder(Component.literal(TABS[i]), x -> {
                tab = idx;
                status = "";
                rebuildWidgets();
            }).bounds(12 + i * (tw + 3), 20, tw, 18).build();
            b.active = tab != i;
            addRenderableWidget(b);
        }
        addRenderableWidget(Button.builder(Component.literal("Done"), b -> onClose())
                .bounds(12, height - 26, 80, 20).build());

        int x1 = 12, x2 = 172, w = 150, y = 48, st = 22;
        switch (tab) {
            case 0 -> {
                toggle(x1, y, w, "Minimap", () -> c.minimapEnabled, v -> c.minimapEnabled = v);
                addRenderableWidget(Button.builder(Component.literal("Shape: " + (c.circular ? "Circle" : "Square")), b -> {
                    c.circular = !c.circular;
                    b.setMessage(Component.literal("Shape: " + (c.circular ? "Circle" : "Square")));
                }).bounds(x1, y + st, w, 20).build());
                addRenderableWidget(new Slider(x1, y + 2 * st, w, 64, 200, c.size,
                        v -> "Size: " + (int) v, v -> c.size = (int) Math.round(v)));
                addRenderableWidget(new Slider(x1, y + 3 * st, w, 30, 100, c.opacity * 100,
                        v -> "Opacity: " + (int) v + "%", v -> c.opacity = (float) (v / 100.0)));
                action(x1, y + 4 * st, 73, "Zoom -", () -> c.zoomIndex = Mth.clamp(c.zoomIndex + 1, 0, 6));
                action(x1 + 77, y + 4 * st, 73, "Zoom +", () -> c.zoomIndex = Mth.clamp(c.zoomIndex - 1, 0, 6));
                toggle(x2, y, w, "Coordinates", () -> c.showCoords, v -> c.showCoords = v);
                toggle(x2, y + st, w, "Dimension", () -> c.showDimension, v -> c.showDimension = v);
                toggle(x2, y + 2 * st, w, "Waypoints", () -> c.showWaypoints, v -> c.showWaypoints = v);
                toggle(x2, y + 3 * st, w, "Names", () -> c.showWaypointNames, v -> c.showWaypointNames = v);
                toggle(x2, y + 4 * st, w, "North (N)", () -> c.showNorth, v -> c.showNorth = v);
                toggle(x2, y + 5 * st, w, "Navigation", () -> c.showNavigation, v -> c.showNavigation = v);
            }
            case 1 -> {
                addRenderableWidget(Button.builder(Component.literal("Scan radius: " + c.scanRadius + " chunks"), b -> {
                    c.scanRadius = next(RADII, c.scanRadius);
                    b.setMessage(Component.literal("Scan radius: " + c.scanRadius + " chunks"));
                }).bounds(x1, y, 200, 20).build());
                addRenderableWidget(Button.builder(Component.literal("Max chunks / dimension: " + c.maxChunks), b -> {
                    c.maxChunks = next(MAXCH, c.maxChunks);
                    b.setMessage(Component.literal("Max chunks / dimension: " + c.maxChunks));
                }).bounds(x1, y + st, 200, 20).build());
            }
            case 2 -> {
                addRenderableWidget(new Slider(x1, y, 200, 250, 1500, c.longPressMs,
                        v -> "Touch long-press: " + (int) v + " ms", v -> c.longPressMs = (int) Math.round(v)));
                addRenderableWidget(Button.builder(Component.literal("Death history: " + c.maxDeathHistory), b -> {
                    c.maxDeathHistory = next(DEATHS, c.maxDeathHistory);
                    b.setMessage(Component.literal("Death history: " + c.maxDeathHistory));
                }).bounds(x1, y + st, 200, 20).build());
            }
            default -> {
                action(x1, y, 150, "Export waypoints", this::doExport);
                action(x2, y, 150, "Import waypoints", this::doImport);
                action(x1, y + st, 150, confirmDim ? "Sure? Clear dimension" : "Clear map: this dimension", () -> {
                    if (!confirmDim) {
                        confirmDim = true;
                        rebuildWidgets();
                        return;
                    }
                    confirmDim = false;
                    MapStore.clearDimension(Dims.key(Minecraft.getInstance().level));
                    status = "Map data cleared for this dimension.";
                    rebuildWidgets();
                });
                action(x2, y + st, 150, confirmWorld ? "Sure? Clear world map" : "Clear map: whole world", () -> {
                    if (!confirmWorld) {
                        confirmWorld = true;
                        rebuildWidgets();
                        return;
                    }
                    confirmWorld = false;
                    MapStore.clearWorld();
                    status = "All map data cleared for this world.";
                    rebuildWidgets();
                });
                action(x1, y + 2 * st, 150, confirmDeaths ? "Sure? Delete deaths" : "Delete all death points", () -> {
                    if (!confirmDeaths) {
                        confirmDeaths = true;
                        rebuildWidgets();
                        return;
                    }
                    confirmDeaths = false;
                    status = WaypointManager.deleteAllDeaths() + " death points deleted.";
                    rebuildWidgets();
                });
                action(x2, y + 2 * st, 150, "Save map now", () -> {
                    MapStore.flush(false);
                    ModConfig.save();
                    status = "Saved.";
                });
            }
        }
    }

    private void doExport() {
        Path p = Storage.dir().resolve("waypoints_export.json");
        int n = WaypointManager.exportTo(p);
        status = "Exported " + n + " waypoints to config/cmd_world_explorer/waypoints_export.json";
    }

    private void doImport() {
        Path p = Storage.dir().resolve("waypoints_import.json");
        if (!Files.isRegularFile(p)) {
            status = "Put a file named waypoints_import.json in config/cmd_world_explorer/ first.";
            return;
        }
        int n = WaypointManager.importFrom(p);
        status = n < 0 ? "Import failed: file is not a valid waypoint file." : "Imported " + n + " waypoints.";
    }

    @Override
    public boolean mouseClicked(MouseButtonEvent event, boolean doubleClick) {
        if (super.mouseClicked(event, doubleClick)) return true;
        if (tab == 0 && event.button() == 0 && mm[2] > 0 && event.x() >= mm[0] && event.x() < mm[0] + mm[2]
                && event.y() >= mm[1] && event.y() < mm[1] + mm[3]) {
            dragging = true;
            dragOffX = (int) (event.x() - mm[0]);
            dragOffY = (int) (event.y() - mm[1]);
            return true;
        }
        return false;
    }

    @Override
    public boolean mouseDragged(MouseButtonEvent event, double dx, double dy) {
        if (dragging) {
            ModConfig c = ModConfig.get();
            c.posX = Mth.clamp((int) event.x() - dragOffX, 0, Math.max(0, width - c.size));
            c.posY = Mth.clamp((int) event.y() - dragOffY, 0, Math.max(0, height - c.size));
            return true;
        }
        return super.mouseDragged(event, dx, dy);
    }

    @Override
    public boolean mouseReleased(MouseButtonEvent event) {
        if (dragging) {
            dragging = false;
            ModConfig.save();
            return true;
        }
        return super.mouseReleased(event);
    }

    @Override
    public void onClose() {
        minecraft.setScreen(parent);
    }

    @Override
    public void removed() {
        ModConfig.save();
    }

    @Override
    public boolean isPauseScreen() {
        return false;
    }

    @Override
    public void renderBackground(GuiGraphics g, int mx, int my, float pt) {
    }

    @Override
    public void render(GuiGraphics g, int mx, int my, float pt) {
        g.fill(0, 0, width, height, 0xE60B0B10);
        UiTheme.panel(g, 8, 28, 322, height - 60);
        UiTheme.title(g, font, "SETTINGS  -  CMD Team", 8, 6);
        int ty = height - 54;
        switch (tab) {
            case 1 -> {
                g.drawString(font, "Only chunks your client has really loaded are drawn.", 14, 100, UiTheme.GRAY, false);
                g.drawString(font, "Saved per world + dimension in config/cmd_world_explorer/maps", 14, 112, UiTheme.GRAY, false);
            }
            case 2 -> {
                g.drawString(font, "Keys (change in Options > Controls > Key Binds):", 14, 100, UiTheme.WHITE, false);
                g.drawString(font, "Z = world map   B = waypoint manager", 14, 112, UiTheme.GRAY, false);
                g.drawString(font, "Add / toggle / zoom keys are unbound until you set them.", 14, 124, UiTheme.GRAY, false);
                g.drawString(font, "Map: click = select, right-click = info, Shift+right = new.", 14, 140, UiTheme.GRAY, false);
                g.drawString(font, "Touch: tap = select, hold = new waypoint, drag = pan.", 14, 152, UiTheme.GRAY, false);
            }
            case 3 -> {
                Minecraft mc = Minecraft.getInstance();
                int chunks = mc.level == null ? 0 : MapStore.chunkCount(Dims.key(mc.level));
                g.drawString(font, "Waypoints (this world): " + WaypointManager.current().size(), 14, 100, UiTheme.WHITE, false);
                g.drawString(font, "Explored chunks (this dimension): " + chunks, 14, 112, UiTheme.WHITE, false);
                g.drawString(font, "Import file: config/cmd_world_explorer/waypoints_import.json", 14, 124, UiTheme.GRAY, false);
            }
            default -> {
                g.drawString(font, "Drag the minimap preview to move it.", 14, 166, UiTheme.GRAY, false);
            }
        }
        if (!status.isEmpty()) g.drawString(font, status, 14, ty, UiTheme.GREEN, false);
        super.render(g, mx, my, pt);
        if (tab == 0) mm = MinimapRenderer.draw(g, Minecraft.getInstance());
        else mm = new int[]{0, 0, 0, 0};
        UiTheme.fadeOverlay(g, width, height, openedAt);
    }
}

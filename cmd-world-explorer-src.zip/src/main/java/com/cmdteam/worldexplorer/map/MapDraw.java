package com.cmdteam.worldexplorer.map;

import com.cmdteam.worldexplorer.data.MapStore;
import com.cmdteam.worldexplorer.data.Waypoint;
import com.cmdteam.worldexplorer.ui.UiTheme;
import com.cmdteam.worldexplorer.util.Geo;
import net.minecraft.Util;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.util.Mth;

import java.util.List;

/** Shared drawing code for the HUD minimap, the world map screen and the settings preview. */
public final class MapDraw {
    /** {pixels per cell, blocks per cell}; higher index = zoomed out. */
    public static final int[][] ZOOMS = {{4, 1}, {3, 1}, {2, 1}, {1, 1}, {1, 2}, {1, 4}, {1, 8}};
    public static final int UNKNOWN = 0x1A1A24;

    private MapDraw() {}

    /** Maps between world blocks and screen pixels. */
    public static final class View {
        public final int x0, y0, w, h, cellPx, bpc, cols, rows, offX, offY, baseX, baseZ;
        public final double cx, cz;

        public View(int x0, int y0, int w, int h, double cx, double cz, int zoomIdx) {
            int[] z = ZOOMS[Mth.clamp(zoomIdx, 0, ZOOMS.length - 1)];
            this.x0 = x0;
            this.y0 = y0;
            this.w = w;
            this.h = h;
            this.cx = cx;
            this.cz = cz;
            cellPx = z[0];
            bpc = z[1];
            cols = Math.max(1, w / cellPx);
            rows = Math.max(1, h / cellPx);
            offX = (w - cols * cellPx) / 2;
            offY = (h - rows * cellPx) / 2;
            baseX = Math.floorDiv((int) Math.floor(cx), bpc) * bpc;
            baseZ = Math.floorDiv((int) Math.floor(cz), bpc) * bpc;
        }

        public double sx(double wx) {
            return x0 + offX + ((wx - baseX) / bpc + cols / 2) * cellPx;
        }

        public double sy(double wz) {
            return y0 + offY + ((wz - baseZ) / bpc + rows / 2) * cellPx;
        }

        public double wx(double sx) {
            return baseX + ((sx - x0 - offX) / cellPx - cols / 2) * bpc;
        }

        public double wz(double sy) {
            return baseZ + ((sy - y0 - offY) / cellPx - rows / 2) * bpc;
        }

        public boolean contains(double sx, double sy, boolean circle) {
            if (!circle) return sx >= x0 && sx < x0 + w && sy >= y0 && sy < y0 + h;
            double dx = sx - (x0 + w / 2.0), dy = sy - (y0 + h / 2.0), r = Math.min(w, h) / 2.0;
            return dx * dx + dy * dy <= r * r;
        }
    }

    /** Pre-computed colour grid; only rebuilt when the view or the map data changes. */
    public static final class TerrainCache {
        int[] px = new int[0];
        int cols, rows, baseX, baseZ, bpc;
        String dim = "";
        long ver = -1, built = 0;

        public void ensure(View v, String dimKey) {
            long now = Util.getMillis();
            boolean same = v.cols == cols && v.rows == rows && v.baseX == baseX && v.baseZ == baseZ
                    && v.bpc == bpc && dimKey.equals(dim);
            long mv = MapStore.version();
            if (same && (mv == ver || now - built < 300)) return;
            if (px.length != v.cols * v.rows) px = new int[v.cols * v.rows];
            int lastCx = Integer.MIN_VALUE, lastCz = Integer.MIN_VALUE;
            int[] arr = null;
            for (int j = 0; j < v.rows; j++) {
                int wz = v.baseZ + (j - v.rows / 2) * v.bpc;
                for (int i = 0; i < v.cols; i++) {
                    int wx = v.baseX + (i - v.cols / 2) * v.bpc;
                    int cx = wx >> 4, cz = wz >> 4;
                    if (cx != lastCx || cz != lastCz) {
                        arr = MapStore.chunk(dimKey, cx, cz);
                        lastCx = cx;
                        lastCz = cz;
                    }
                    px[j * v.cols + i] = arr == null ? 0 : arr[((wz & 15) << 4) | (wx & 15)];
                }
            }
            cols = v.cols;
            rows = v.rows;
            baseX = v.baseX;
            baseZ = v.baseZ;
            bpc = v.bpc;
            dim = dimKey;
            ver = mv;
            built = now;
        }
    }

    public static void drawTerrain(GuiGraphics g, TerrainCache c, View v, boolean circle, float opacity) {
        double rad = Math.min(v.w, v.h) / 2.0;
        for (int j = 0; j < c.rows; j++) {
            int i0 = 0, i1 = c.cols;
            if (circle) {
                double dy = (v.offY + (j + 0.5) * v.cellPx) - v.h / 2.0;
                double half = Math.sqrt(Math.max(0, rad * rad - dy * dy));
                i0 = Math.max(0, (int) Math.ceil((v.w / 2.0 - half - v.offX) / v.cellPx));
                i1 = Math.min(c.cols, (int) Math.floor((v.w / 2.0 + half - v.offX) / v.cellPx));
            }
            int i = i0;
            while (i < i1) {
                int col = c.px[j * c.cols + i];
                int k = i + 1;
                while (k < i1 && c.px[j * c.cols + k] == col) k++;
                int rgb = col == 0 ? UNKNOWN : (col & 0xFFFFFF);
                g.fill(v.x0 + v.offX + i * v.cellPx, v.y0 + v.offY + j * v.cellPx,
                        v.x0 + v.offX + k * v.cellPx, v.y0 + v.offY + (j + 1) * v.cellPx,
                        UiTheme.withAlpha(rgb, opacity));
                i = k;
            }
        }
    }

    public static void drawFrame(GuiGraphics g, View v, boolean circle) {
        int c = UiTheme.PURPLE;
        if (!circle) {
            UiTheme.border(g, v.x0 - 1, v.y0 - 1, v.w + 2, v.h + 2, c);
            return;
        }
        double r = Math.min(v.w, v.h) / 2.0, cx = v.x0 + v.w / 2.0, cy = v.y0 + v.h / 2.0;
        int steps = (int) Math.max(60, r * 3);
        for (int i = 0; i < steps; i++) {
            double a = Math.PI * 2 * i / steps;
            int x = (int) Math.round(cx + Math.cos(a) * (r + 1)), y = (int) Math.round(cy + Math.sin(a) * (r + 1));
            g.fill(x - 1, y - 1, x + 1, y + 1, c);
        }
    }

    public static void drawNorth(GuiGraphics g, View v) {
        Font f = Minecraft.getInstance().font;
        g.drawString(f, "N", v.x0 + v.w / 2 - 3, v.y0 + 2, UiTheme.RED, true);
    }

    public static void line(GuiGraphics g, double x1, double y1, double x2, double y2, int color) {
        int n = (int) Math.ceil(Math.max(Math.abs(x2 - x1), Math.abs(y2 - y1)));
        if (n < 1) n = 1;
        for (int i = 0; i <= n; i++) {
            int x = (int) Math.round(x1 + (x2 - x1) * i / n), y = (int) Math.round(y1 + (y2 - y1) * i / n);
            g.fill(x - 1, y - 1, x + 1, y + 1, color);
        }
    }

    /** Arrow pointing along the unit vector (fx, fy) in screen space. */
    public static void drawArrow(GuiGraphics g, double cx, double cy, double fx, double fy, double s, int color) {
        double px = -fy, py = fx;
        double tx = cx + fx * 6 * s, ty = cy + fy * 6 * s;
        double lx = cx - fx * 4 * s + px * 4 * s, ly = cy - fy * 4 * s + py * 4 * s;
        double rx = cx - fx * 4 * s - px * 4 * s, ry = cy - fy * 4 * s - py * 4 * s;
        for (int k = 0; k <= 6; k++) {
            double t = k / 6.0;
            line(g, tx, ty, lx + (rx - lx) * t, ly + (ry - ly) * t, color);
        }
    }

    public static void drawPlayer(GuiGraphics g, View v, double px, double pz, float yawDeg) {
        double sx = v.sx(px), sy = v.sy(pz);
        double r = Math.toRadians(yawDeg);
        double fx = -Math.sin(r), fy = Math.cos(r);
        drawArrow(g, sx + 1, sy + 1, fx, fy, 1.0, 0xAA000000);
        drawArrow(g, sx, sy, fx, fy, 1.0, 0xFFFFFFFF);
    }

    public static void drawMarkers(GuiGraphics g, View v, boolean circle, List<Waypoint> list, String dim,
                                   boolean names, Waypoint nav) {
        Font font = Minecraft.getInstance().font;
        double ccx = v.x0 + v.w / 2.0, ccy = v.y0 + v.h / 2.0;
        int labels = 0;
        for (Waypoint w : list) {
            if (!w.dimension.equals(dim)) continue;
            double sx = v.sx(w.x + 0.5), sy = v.sy(w.z + 0.5);
            boolean inside = v.contains(sx, sy, circle);
            boolean isNav = nav != null && w.id.equals(nav.id);
            if (!inside) {
                if (!isNav) continue;
                if (circle) {
                    double dx = sx - ccx, dy = sy - ccy, d = Math.hypot(dx, dy), r = Math.min(v.w, v.h) / 2.0 - 5;
                    if (d > r && d > 0) {
                        sx = ccx + dx / d * r;
                        sy = ccy + dy / d * r;
                    }
                } else {
                    sx = Mth.clamp(sx, v.x0 + 5, v.x0 + v.w - 5);
                    sy = Mth.clamp(sy, v.y0 + 5, v.y0 + v.h - 5);
                }
            }
            w.iconType().drawShadowed(g, (int) Math.round(sx) - 3, (int) Math.round(sy) - 3, 1, w.color);
            if (names && inside && labels < 12) {
                String n = Geo.shorten(w.name, 12);
                g.drawString(font, n, (int) Math.round(sx) - font.width(n) / 2, (int) Math.round(sy) + 5, 0xFFFFFFFF, true);
                labels++;
            }
        }
    }
}

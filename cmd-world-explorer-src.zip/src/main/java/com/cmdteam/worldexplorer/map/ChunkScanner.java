package com.cmdteam.worldexplorer.map;

import com.cmdteam.worldexplorer.data.Dims;
import com.cmdteam.worldexplorer.data.MapStore;
import com.cmdteam.worldexplorer.data.ModConfig;
import net.minecraft.client.Minecraft;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.core.BlockPos;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.chunk.LevelChunk;
import net.minecraft.world.level.levelgen.Heightmap;
import net.minecraft.world.level.material.MapColor;

import java.util.HashMap;
import java.util.Map;

/**
 * Reads colours only from chunks the client has actually received.
 * Max 1 chunk per tick, each chunk rescanned at most every 10 s.
 */
public final class ChunkScanner {
    private static final Map<Long, Long> LAST = new HashMap<>();
    private static long tick = 0;
    private static int cursor = 0;

    private ChunkScanner() {}

    public static void reset() {
        LAST.clear();
        cursor = 0;
    }

    public static void tick(Minecraft mc) {
        ClientLevel level = mc.level;
        LocalPlayer p = mc.player;
        if (level == null || p == null) return;
        tick++;
        String dim = Dims.key(level);
        int r = ModConfig.get().scanRadius;
        int side = 2 * r + 1, total = side * side;
        int pcx = p.getBlockX() >> 4, pcz = p.getBlockZ() >> 4;
        for (int i = 0; i < total; i++) {
            int idx = (cursor++) % total;
            int cx = pcx + idx % side - r, cz = pcz + idx / side - r;
            if (!level.hasChunk(cx, cz)) continue;
            long key = dim.hashCode() * 31L + MapStore.key(cx, cz);
            Long last = LAST.get(key);
            if (last != null && tick - last < 200) continue;
            LAST.put(key, tick);
            scan(level, p, dim, cx, cz);
            return;
        }
        if (LAST.size() > 50000) LAST.clear();
    }

    private static void scan(ClientLevel level, LocalPlayer p, String dim, int cx, int cz) {
        LevelChunk chunk = level.getChunk(cx, cz);
        boolean nether = level.dimension() == Level.NETHER;
        int[] out = new int[256];
        BlockPos.MutableBlockPos pos = new BlockPos.MutableBlockPos();
        int startNether = Math.min(p.getBlockY() + 1, 120);
        for (int lz = 0; lz < 16; lz++) {
            for (int lx = 0; lx < 16; lx++) {
                int wx = (cx << 4) + lx, wz = (cz << 4) + lz;
                int y = nether ? startNether : chunk.getHeight(Heightmap.Types.WORLD_SURFACE, lx, lz) - 1;
                BlockState st = level.getBlockState(pos.set(wx, y, wz));
                int steps = 0;
                while (steps < (nether ? 100 : 16) && (st.isAir() || st.getMapColor(level, pos) == MapColor.NONE)) {
                    y--;
                    steps++;
                    st = level.getBlockState(pos.set(wx, y, wz));
                }
                if (st.isAir()) continue;
                MapColor mc = st.getMapColor(level, pos);
                if (mc == MapColor.NONE) continue;
                float f = 1.0f;
                if (!nether && st.getFluidState().isEmpty() && level.hasChunk(wx >> 4, (wz - 1) >> 4)) {
                    int hn = level.getHeight(Heightmap.Types.WORLD_SURFACE, wx, wz - 1) - 1;
                    f = y > hn ? 1.12f : (y < hn ? 0.82f : 1.0f);
                }
                out[(lz << 4) | lx] = 0xFF000000 | scale(mc.col, f);
            }
        }
        MapStore.put(dim, cx, cz, out);
    }

    private static int scale(int rgb, float f) {
        int r = Math.min(255, (int) (((rgb >> 16) & 255) * f));
        int g = Math.min(255, (int) (((rgb >> 8) & 255) * f));
        int b = Math.min(255, (int) ((rgb & 255) * f));
        return (r << 16) | (g << 8) | b;
    }
}

package com.cmdteam.worldexplorer.map;

import com.cmdteam.worldexplorer.data.Dims;
import com.cmdteam.worldexplorer.data.ModConfig;
import com.cmdteam.worldexplorer.data.Waypoint;
import com.cmdteam.worldexplorer.data.WaypointManager;
import com.cmdteam.worldexplorer.ui.MapScreen;
import com.cmdteam.worldexplorer.ui.SettingsScreen;
import com.cmdteam.worldexplorer.ui.UiTheme;
import com.cmdteam.worldexplorer.util.Geo;
import net.minecraft.client.DeltaTracker;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.util.Mth;

import java.util.Locale;

/** The corner minimap + coordinates + navigation panel. */
public final class MinimapRenderer {
    private static final MapDraw.TerrainCache CACHE = new MapDraw.TerrainCache();

    private MinimapRenderer() {}

    public static void renderHud(GuiGraphics g, DeltaTracker dt) {
        Minecraft mc = Minecraft.getInstance();
        ModConfig c = ModConfig.get();
        if (!c.minimapEnabled || mc.player == null || mc.level == null || mc.options.hideGui) return;
        if (mc.screen instanceof MapScreen || mc.screen instanceof SettingsScreen) return;
        draw(g, mc);
    }

    /** Draws the minimap and returns its rectangle {x, y, w, h}. */
    public static int[] draw(GuiGraphics g, Minecraft mc) {
        ModConfig c = ModConfig.get();
        LocalPlayer p = mc.player;
        Font font = mc.font;
        int sw = mc.getWindow().getGuiScaledWidth(), sh = mc.getWindow().getGuiScaledHeight();
        int size = c.size;
        int x = c.posX < 0 ? sw - size - 6 : Mth.clamp(c.posX, 0, Math.max(0, sw - size));
        int y = Mth.clamp(c.posY, 0, Math.max(0, sh - size));
        String dim = Dims.key(mc.level);
        double px = p.getX(), pz = p.getZ();

        MapDraw.View v = new MapDraw.View(x, y, size, size, px, pz, c.zoomIndex);
        CACHE.ensure(v, dim);
        MapDraw.drawTerrain(g, CACHE, v, c.circular, c.opacity);
        if (c.showWaypoints) {
            MapDraw.drawMarkers(g, v, c.circular, WaypointManager.current(), dim, c.showWaypointNames, WaypointManager.navTarget());
        }
        MapDraw.drawPlayer(g, v, px, pz, p.getYRot());
        MapDraw.drawFrame(g, v, c.circular);
        if (c.showNorth) MapDraw.drawNorth(g, v);

        int ty = y + size + 4;
        if (c.showCoords) {
            String s = String.format(Locale.ROOT, "X %d  Y %d  Z %d", p.getBlockX(), p.getBlockY(), p.getBlockZ());
            g.drawString(font, s, x + (size - font.width(s)) / 2, ty, UiTheme.WHITE, true);
            ty += 10;
        }
        if (c.showDimension) {
            String s = Dims.pretty(dim);
            g.drawString(font, s, x + (size - font.width(s)) / 2, ty, Dims.color(dim), true);
            ty += 10;
        }
        Waypoint t = WaypointManager.navTarget();
        if (c.showNavigation && t != null) drawNav(g, font, p, t, dim, x, ty + 2, Math.max(size, 110));
        return new int[]{x, y, size, size};
    }

    private static void drawNav(GuiGraphics g, Font font, LocalPlayer p, Waypoint t, String dim, int x, int y, int w) {
        boolean same = t.dimension.equals(dim);
        g.fill(x, y, x + w, y + 34, 0xB0000000);
        UiTheme.border(g, x, y, w, 34, UiTheme.PURPLE_DARK);
        t.iconType().drawShadowed(g, x + 4, y + 4, 1, t.color);
        g.drawString(font, Geo.shorten(t.name, 16), x + 14, y + 4, UiTheme.WHITE, true);
        g.drawString(font, "X " + t.x + " Y " + t.y + " Z " + t.z, x + 4, y + 14, UiTheme.GRAY, false);
        String d = same ? Geo.fmtDist(t.distanceTo(p.getX(), p.getY(), p.getZ())) : "In " + Dims.pretty(t.dimension);
        g.drawString(font, d, x + 4, y + 24, same ? UiTheme.GREEN : UiTheme.RED, false);
        if (same) {
            double rel = Math.toRadians(Geo.relativeAngle(p, t.x, t.z));
            MapDraw.drawArrow(g, x + w - 14, y + 18, Math.sin(rel), -Math.cos(rel), 1.4, 0xFFC084FC);
        }
    }
}
